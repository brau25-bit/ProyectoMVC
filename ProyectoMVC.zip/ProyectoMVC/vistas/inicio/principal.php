<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-dashboard"></i> Estadisticas</h1>
            <p>Total de productos</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li><a href="#">Dashboard</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md">
            <div class="card">
              <h3 class="card-title">Cantidad Productos</h3>
                <p><?php $p=$this->modelo->Cantidad()?>
                <?=$p->Cantidad?>   
              </p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md">
            <div class="card">
              <h3 class="card-title">Ventas estimadas</h3>
                <p><?php $p=$this->modelo->Ganancias()?>
                <?=$p->Ganancias?>$ de ganancias totales
                </p>
            </div>
          </div>
        </div>
      </div>
    </div>